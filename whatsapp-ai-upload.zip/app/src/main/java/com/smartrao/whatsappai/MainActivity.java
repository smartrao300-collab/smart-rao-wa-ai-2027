package com.smartrao.whatsappai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 40, 32, 32);

        TextView title = new TextView(this);
        title.setText("WhatsApp AI Auto Reply");
        title.setTextSize(24);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("\nFree setup\n\n1. Enable notification access.\n2. Keep the local AI server running.\n3. Test before enabling automatic replies.\n");
        info.setTextSize(16);
        layout.addView(info);

        Button access = new Button(this);
        access.setText("Open Notification Access Settings");
        access.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        );
        layout.addView(access);

        setContentView(layout);
    }
}
