package com.smartrao.whatsappai;

import android.app.Notification;
import android.app.Notification.Action;
import android.app.RemoteInput;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

public class WaListener extends NotificationListenerService {
    private static final String TAG = "WaAI";
    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !WHATSAPP_BUSINESS.equals(sbn.getPackageName())) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null || n.actions == null) return;

        CharSequence title = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = n.extras.getCharSequence(Notification.EXTRA_TEXT);
        if (text == null || text.toString().trim().isEmpty()) return;

        // Find the notification's supported text-reply action.
        Action replyAction = null;
        RemoteInput[] inputs = null;
        for (Action action : n.actions) {
            if (action == null || action.getRemoteInputs() == null) continue;
            for (RemoteInput ri : action.getRemoteInputs()) {
                if (ri != null && ri.getAllowFreeFormInput()) {
                    replyAction = action;
                    inputs = action.getRemoteInputs();
                    break;
                }
            }
            if (replyAction != null) break;
        }
        if (replyAction == null || inputs == null) return;

        final Action chosenAction = replyAction;
        final RemoteInput[] chosenInputs = inputs;
        final String incoming = text.toString();
        final String contact = title == null ? "Customer" : title.toString();

        worker.execute(() -> {
            try {
                String answer = getReply(contact, incoming);
                if (answer == null || answer.trim().isEmpty()) return;

                Intent replyIntent = new Intent();
                Bundle results = new Bundle();
                for (RemoteInput ri : chosenInputs) {
                    if (ri != null && ri.getAllowFreeFormInput()) {
                        results.putCharSequence(ri.getResultKey(), answer);
                    }
                }
                RemoteInput.addResultsToIntent(chosenInputs, replyIntent, results);
                chosenAction.actionIntent.send(this, 0, replyIntent);
                Log.i(TAG, "Reply sent to notification action.");
            } catch (Exception e) {
                Log.e(TAG, "Auto-reply failed", e);
            }
        });
    }

    private String getReply(String contact, String message) throws Exception {
        JSONObject body = new JSONObject();
        body.put("message", "Contact: " + contact + "\nIncoming message: " + message
                + "\nWrite a short, helpful WhatsApp reply.");
        byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);

        HttpURLConnection conn = (HttpURLConnection)
                new URL("http://127.0.0.1:5000/get-ai-reply").openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");

        try (OutputStream os = conn.getOutputStream()) {
            os.write(data);
        }

        int status = conn.getResponseCode();
        if (status < 200 || status >= 300) {
            conn.disconnect();
            return null;
        }

        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) response.append(line);
        } finally {
            conn.disconnect();
        }

        JSONObject result = new JSONObject(response.toString());
        String reply = result.optString("reply", result.optString("text", ""));
        return reply;
    }

    @Override
    public void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
